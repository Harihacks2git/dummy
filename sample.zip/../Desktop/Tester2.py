print("This is another testing code")
for i in range(0,5):
    print(i)
